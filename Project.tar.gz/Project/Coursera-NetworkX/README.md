# Coursera-NetworkX

Reference Python notebooks for the 
"Network Data Science with NetworkX and Python"
guided course. (https://rhyme.com/c/network-data-science-with-networkx-and-python/12019)




8.5+6.5+6+6+5.5+5.5+5.5
5+6+6+4+4+8+4